"use strict";

const domain = "https://jsonplaceholder.typicode.com";

const getTodo = async id => {

    if (id < 1 || id > 10) {
        return Promise.reject( new Error ("User ID msut be between 1 and 10"));
    }

    else {

        const r1 = await fetch(`${domain}/todos/${id}`);
        const todo = await r1.json();

        const r2 = await fetch(`${domain}/users/${todo.id}`)
        const user = await r2.json();
        todo.user = user;

        

        return todo;
    }
};

const todoData = todo => {
    let html = `<h3>To-Do: ${todo.title}</h3>`;
    html    += `<h4>Name: ${todo.user.name}</h4>`;
    html    += `<p>Username: ${todo.user.username}</p>`;
    html    += `<p>User Email: ${todo.user.email}</p>`;
    html    += `<p>Completed: ${todo.completed}</p>`
    $("#todo").html(html);
};

const displayError = e => {
    let html = `<span>${e}</span>`;
    $("#todo").html(html);
};

$(document).ready( () => {

    $("#view_button").click( async () => {
        const todo_id = $("#todo_id").val();

        try{
            const todo = await getTodo(todo_id);

            todoData(todo);
        }
        catch(e){
            displayError(e);
        }
    });
});