const $ = selector => document.querySelector(selector);

let firScore = "";
let secScore = "";
let thirScore = "";
let fourScore = "";
let tStudent = "";

const calcGrade = evt => {
    // get user entries from the text boxes
    const score1 = $("#score_1").value;
    firScore = score1;
    const score2 = $("#score_2").value;
    secScore = score1;
    const score3 = $("#score_3").value;
    thirScore = score3;
    const score4 = $("#score_4").value;
    fourScore = score4;
    const student = $("#student").value;
    tStudent = student;

    //check user entries

    let isvalid = true;

    if (student == "") {
        $("student_error").textcontent = "Student name is required.";
        isvalid = false;
    }
    else {
        $("#student_error").textcontent = "";
    }

    if (score1 == "") {
        $("#score_1_error").textcontent = "Score is required.";
        isvalid = false;
    }
    else {
        $("#score_1_error").textcontent = "";
    }


    if (score2 == "") {
        $("#score_2_error").textcontent = "Score is required.";
        isvalid = false;
    }
    else {
        $("#score_2_error").textcontent = "";
    }

    if (score3 == "") {
        $("#score_3_error").textcontent = "Score is required.";
        isvalid = false;
    }
    else {
        $("#score_3_error").textcontent = "";
    }

    if (score4 == "") {
        $("#score_4_error").textcontent = "Score is required.";
        isvalid = false;
    }
    else {
        $("#score_4_error").textcontent = "";
    }


    

    //cancel form submit if any user entries are invalid
    if (isvalid = false) {
        evt.preventDefault();
    }


};


const clearform = () => {
    //clear text boxes
    $("student").value = "";
    $("score_1").value = "";
    $("score_2").value = "";
    $("score_3").value = "";
    $("score_4").value = "";

    //clear span elements
    $("student_error").textContent = "*";
    $("score_1_error").textContent = "*";
    $("score_2_error").textContent = "*";
    $("score_3_error").textContent = "*";
    $("score_4_error").textContent = "*";
    

    //set focus on first box after resetting form
    $("#student").focus();
};

total = (firScore * .2) + (secScore * .2) + (thirScore * .25) + (fourScore * .35);

document.addEventListener("DOMContentLoaded", () => {
    //hook up click events for both buttons
    $("calc_grade").addEventListener("click", calcGrade);

    function myFunction() {
        alert("Student: " + (tStudent) + "\nFirst Score:" +(firScore) + "\nSecond Score: " + (secScore)
        + "\nThird Score: " + (thirScore) + "\nFourth Score: " + (fourScore) + "\nFinal Average: " + (total));
      }
    

    $("clear_form").addEventListener("click", clearform);

    //set focus on first text box after the form loads
    $("#student").focus();
});



